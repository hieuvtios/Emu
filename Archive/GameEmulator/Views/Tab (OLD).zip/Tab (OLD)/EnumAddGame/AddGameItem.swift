//
//  AddGameItem.swift
//  GoEmulator
//
//  Created by Đỗ Việt on 5/10/25.
//

import SwiftUI

struct AddGameItem {
    let name: String
    let Image: String
}

